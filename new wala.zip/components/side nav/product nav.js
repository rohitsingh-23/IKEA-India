function productnav(){
    return `<div class="promain">
    <div class="cross-logo">
      <div class="proclose"><ion-icon name="close-outline"></ion-icon></div>
  
      <div class="logo1">
        <img
          src="https://www.ikea.com/in/en/static/ikea-logo.f7d9229f806b59ec64cb.svg"
          alt=""
        />
      </div>
    </div>
    <div class="procontent-toggle">
     <div>
        
      <div class="h1">
        <h2>Products</h2>
     
      </div>
  
      <div class="h1-bottom">
        <p>New lower price</p>
        <p>Handpicked combinations for a new fresh look</p>
        <p>Highest rated products</p>
        <p>Sustainable living</p>
        <p>Product guides</p>
        
      </div>
  
      <div class="bottom-most">
        <p id="furn">Furniture
        </p>
        <p>Kichen & appliances</p>
        <p>Beds & mattresses</p>
        <p>Storage & organisation</p>
        <p>Working from home</p>
        <p>textiles</p>
        <p>Decoration</p>
        <p>Bathroom products</p>
        <p>Outdoor products</p>
        <p id="light">Lighting</p>
        <p>Carpets,mats&flooring</p>
        <p>Baby & children</p>
        <p><a href="#">More</a></p>
      </div>
     </div>
     <div id="sub-menu">
     <div class="h1">
     <h2>Lighting</h2>
   
   </div>
   
   <div class="h1-bottom">
     <p>Shop all</p>
   
     
   </div>
   
   <div class="bottom-most">
     <p>Lamps
     </p>
     <p>Decorating lighting</p>
     <p>Integrated lighting</p>
     <p>Smart lighting</p>
     <p>Outdoor lighting</p>
     <p>Bathroom lighting</p>
   
   </div>
     </div>

  </div>
</div>`
}

export default productnav