function login(){
    return `<div id = "bordy">
    <div id = "uppro">
        <br>
      <div id = "crossb"><button id = "cros">✕</button></div>
      <br><br><br><br>
        <div class = "textBut">Hej</div>
      <div class = "textBut"><button id = "logButton">Log in</button></div>
     <br><br> <hr>
<br>
        <div>
     <div class = "tex">
        
         <div class = "heady">Join IKEA Family</div>
         <div class = "pery">Get access to a number of member benefits. Enjoy <br>guaranteed discounts, free workshops, exclusive previews <br>and a lot more when you join. Its free!</div>
            
     </div>
     <div class = "symb">
         <br>
         <button id="homelogin" class = "gtSym"><img src="https://icon-library.com/images/arrow-text-icon/arrow-text-icon-29.jpg" alt="" width="55%" height="55%"></button>
     </div>
    </div>
    <hr>

    <div>
        <div class = "tex">
            <div class = "heady">Join IKEA Business Network</div>
            <div class = "pery">Get easy access to services, offers and benefits to help your<br> business needs. Together, we can help your business to grow.<br> It's free!</div>
        </div>
        <div class = "symb">
            <br>
            <button class = "gtSym"><img src="https://icon-library.com/images/arrow-text-icon/arrow-text-icon-29.jpg" alt=""></button>
        </div>
       </div>





    </div>
    <br><br>
    <div style="margin-left: 30px;"><a href=""><font color = "none">Shopping list</font></a></div>
    <br>
    <div style="margin-left: 30px;"><a href=""><font color = "none">Planners</font></a></div>

</div>`
}

export default login 