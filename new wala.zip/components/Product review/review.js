function review(){
    return `<div id = "mainreview">
    <div id="forBut">
        <br>
        <div id="cclose"><button id="ciross">✖</button></div>
    </div>


    <div id="ratDiv">
        <br>
        <div style="margin-left: 35px;font-size: 25px;font-weight: bold;">Reviews</div>
        <br><br>
        <div id="five" style="margin-left: 35px;">4.5</div>
        <div style="margin-left: 35px;" class="starsss">★★★★★</div>
        <br><br>
        <div class="smHead" style="margin-left: 35px;">Average customer ratings</div>
        <br>


        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>



            <div class="rightDif">
                <img src="./img/average.png" alt="">
            </div>

        </div>
        <br>
        <br>
        
        <div style="margin-left: 35px;" class="smHead">Good product</div>
        <div style="margin-left: 35px;" class="starsss">★★★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">Vinu - 05-08-2021</font></div>
        <div style="margin-left: 35px;" class="ravText">Good product</div><br>

        <div class="recoText" style="margin-left: 35px;">✔ Yes, I recommend this product</div>
        <br>


        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>



            <div class="rightDif">
                <img src="./img/good.png" alt="">
            </div>
            
            
            
            
        </div>
        <br>
        <div class = "smHead" style="margin-left: 35px;">Value For Money</div><br>
        <div class = "starss" style="margin-left: 35px;">★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">Ravin - 06-07-2021</font></div>

        <div class = "ravText" style="margin-left: 35px;">Excellent Product. Only issue was that i was not able<br> to see my order history on Ikea mobile nor on website.<br> Looks like Ikea is far behind i would say decades behind<br> for online ordering system. You should update.</div>
        <br>
        <div class="recoText" style="margin-left: 35px;">✔ Yes, I recommend this product</div>
        <br>


     


        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>



            <div class="rightDif">
                <img src="./img/value.png" alt="">
            </div>  
            
            
            
            
        </div>
        <br>

        <div class = "smHead" style="margin-left: 35px;">Nice modern dinning set</div>
        <br>
        <div class = starsss style="margin-left: 35px;">★★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">Afsar - 02-07-2021</font></div>
        <div class = "ravText" style="margin-left: 35px;">Received the item bit late but was worth waiting, colour<br> is good, strong enough material. Only problem I faced <br>is while assembling the table is the holes are not<br> aligned with the metal frame. Chairs are very easy to,<br> assemble. Tools for assembly are included in the package which is quite helpful.</div>
        <br>
        <div class="recoText" style="margin-left: 35px;">✔ Yes, I recommend this product</div>
        <br>


        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>
            <div class="rightDif">
                <img src="./img/nice.png" alt="">
            </div>
        </div>

        <br>

        <div class="smHead" style="margin-left: 35px;">Response from IKEA</div>
        <div class = "ravText" style="margin-left: 35px;">IKEA - 05-07-2021</div>
        <br>
        <div class="ravText" style="margin-left: 35px;">Hej, Your feedback is duly noted and apologies for any<br> inconvenience caused. The information has been <br>conveyed to our relevant team and the team will <br>certainly look into your inputs.</div>

        <br><br>

        <div class="smHead" style="margin-left: 35px;">Very good quality</div>
     
        <div class = "starsss" style="margin-left: 35px;">★★★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">Nikhil - 25-06-2021</font></div>
        <div class="ravText" style="margin-left: 35px;">useful and light weight and great look</div>
        <br>
        <div class="recoText" style="margin-left: 35px;">✔ Yes, I recommend this product</div>

        <br>
        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>
            <div class="rightDif">
                <img src="./img/very.png" alt="">
            </div>
        </div>
        <br>
        <div class="smHead" style="margin-left: 35px;">Worthfull item</div>
        
        <div class="starsss" style="margin-left: 35px;">★★★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">Ramesh - 15-05-2021</font></div>
        <div class = "ravText" style="margin-left: 35px; ">useful and light weight and great look</div>
        <div class="recoText" style="margin-left: 35px; margin-top: 10px;">✔ Yes, I recommend this product</div>
        <br>

        <div class="difDiv" style="margin-left: 35px;">


            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>
            <div class="rightDif">
                <img src="./img/very.png" alt="">
            </div>
        </div>
        <br>
        <div class="smHead" style="margin-left: 35px;margin-bottom: 10px;">good</div>
        <div class = "starsss" style="margin-left: 35px;">★★★★★ ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ <font size = "2px" color = "grey">sasikanth - 13-12-2020</font></div>
        <div class="ravText" style="margin-left: 35px;margin-bottom: 10px;">good</div>

        <div class="recoText" style="margin-left: 35px; margin-top: 10px;">✔ Yes, I recommend this product</div>

        <br>
        <div class="difDiv" style="margin-left: 35px;">
            <div class="leftDif">
                <div class="ravText">Ease of assembly/installation</div>
                <div class="ravText">Value for money</div>
                <div class="ravText">Product quality</div>
                <div class="ravText">Appearance</div>
                <div class="ravText">Works as expected</div>
            </div>
            <div class="rightDif">
                <img src="./img/worth.png" alt="">
            </div>
</div>`
}

export default review 