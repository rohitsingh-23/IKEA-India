num = 3;

function fact(num){
    if(num==1 || num ==0){
        return 1;
    }
    num * fact(num-1)

}