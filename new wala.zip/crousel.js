// const track = document.getElementsByClassName('crousel_track')
// // let track = document.querySelector(".crousel_track")
// // let slides = track;
// // const slides = Array.from(track.children)
// console.log(track)
// console.log(slides)

product = [{
    img1: "",
    img2: "",
    title: "",
    des: "",
    price: 6390,
    varient:true,
    vimg1 : "",
    vimg2: "",
    vimg3: ""
},{},{}]

